import pytest
from mybox_diag import overview

@pytest.mark.parametrize('state,level',[('passed','good'),('failed','bad'),('warning','attention'),('needs_action','attention'),('not_tested','attention'),('running','attention')])
def test_module_health_never_hides_incomplete_or_failed_checks(state,level):
    tests={'sd.read':{'applicable':True},'sd.write':{'applicable':True}}
    result={'sd.read':{'state':'passed'},'sd.write':{'state':state}}
    assert overview.module_health(tests,result,True,True)[0]==level
    assert overview.module_health(tests,result,False,True)[0]=='neutral'
    if state=='passed':
        assert overview.module_health(tests,result,True,False)[0]!='good'
        assert overview.module_health(tests,result,True,True,fresh=False)[0]!='good'

def test_sd_has_its_own_read_write_block_and_every_catalog_test_has_a_block():
    import json
    from pathlib import Path
    catalog=json.loads((Path(__file__).parents[1]/'pc/mybox_diag/test_catalog.json').read_text())
    modules={key for key,_,_ in overview.MODULES}
    assert len(modules)==10
    for test in catalog:assert overview.module_for(test['test']) in modules
    assert overview.module_for('sd.read')==overview.module_for('sd.write')=='sd'
    assert overview.module_for('flash.read')=='flash'

def test_overview_keeps_board_visible_and_confirmation_inside_module(tmp_path,monkeypatch):
    from types import SimpleNamespace as NS
    from PySide6.QtWidgets import QApplication,QTabWidget
    from mybox_diag.app import Window
    from mybox_diag.simulator import DemoPeer
    from mybox_diag.protocol import Frame
    app=QApplication.instance() or QApplication([])
    window=Window(NS(output=str(tmp_path),demo=False,smoke_demo=False));window.show();window._new_session(True);window.on_status('ДЕМОНСТРАЦИЯ')
    commands=[];monkeypatch.setattr(window,'command',lambda op,**kw:commands.append((op,kw)))
    try:
        peer=DemoPeer();window.on_frames(peer.request({'id':1,'op':'info'})+peer.request({'id':2,'op':'list'}));window.on_frames(peer.poll());window.refresh_view();app.processEvents()
        assert not window.findChildren(QTabWidget) and window.view.isVisible()
        sd=window.cards['sd'];sd.header.click();app.processEvents();assert sd.body.isVisible() and window.view.isVisible()
        sd.rows['sd.write'].click();assert window.selected_test()=='sd.write' and window.single.isEnabled()
        window.single.click();assert commands[-1][1]['test']=='sd.write'
        signals=window.cards['signals'];signals.header.click();signals.rows['led.visual'].click()
        window.on_frames([Frame(3,999,100,{'event':'result','test':'led.visual','state':'needs_action','code':'OPERATOR_CONFIRM'})])
        app.processEvents();assert window.accept.isVisible() and window.view.isVisible()
        window.accept.click();assert commands[-1]==('confirm',{'test':'led.visual','confirm':True})
    finally:window.close();app.processEvents()
