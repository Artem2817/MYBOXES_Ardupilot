from PySide6.QtCore import Qt
from PySide6.QtWidgets import QFrame,QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton
from .overview import COLORS,test_label

class ModuleCard(QFrame):
    def __init__(self,key,title,subtitle,select,parent=None):
        super().__init__(parent);self.key=key;self.select=select;self.rows={};self.setObjectName('moduleCard')
        layout=QVBoxLayout(self);layout.setContentsMargins(16,12,16,12);layout.setSpacing(0)
        self.header=QPushButton();self.header.setObjectName('cardHeader');self.header.setMinimumHeight(70);self.header.setCursor(Qt.CursorShape.PointingHandCursor)
        line=QHBoxLayout(self.header);line.setContentsMargins(0,0,0,0);line.setSpacing(12)
        self.dot=QLabel('●');self.dot.setFixedWidth(14);line.addWidget(self.dot)
        names=QVBoxLayout();names.setSpacing(3);self.title=QLabel(title);self.title.setObjectName('cardTitle');names.addWidget(self.title)
        self.state=QLabel('Ожидание');self.state.setObjectName('cardState');names.addWidget(self.state)
        self.subtitle=QLabel(subtitle);self.subtitle.setObjectName('muted');self.subtitle.setWordWrap(True);names.addWidget(self.subtitle);line.addLayout(names,1)
        self.arrow=QLabel('⌄');self.arrow.setObjectName('muted');line.addWidget(self.arrow)
        for label in (self.dot,self.title,self.subtitle,self.state,self.arrow):label.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        layout.addWidget(self.header);self.body=QWidget();self.body_layout=QVBoxLayout(self.body);self.body_layout.setContentsMargins(0,14,0,0);self.body_layout.setSpacing(5)
        self.live=QLabel();self.live.setObjectName('liveData');self.live.setWordWrap(True);self.body_layout.addWidget(self.live)
        self.tests_layout=QVBoxLayout();self.tests_layout.setSpacing(4);self.body_layout.addLayout(self.tests_layout)
        layout.addWidget(self.body);self.body.hide();self.header.clicked.connect(self.toggle)
        self.set_health('neutral','Ожидание',subtitle)
    def toggle(self):
        self.body.setVisible(self.body.isHidden());self.arrow.setText('⌄' if self.body.isHidden() else '⌃')
    def set_health(self,level,state,subtitle):
        color=COLORS[level];self.dot.setStyleSheet(f'color:{color}');self.state.setStyleSheet(f'color:{color}');self.state.setText(state);self.subtitle.setText(subtitle)
    def update_test(self,key,result):
        if key not in self.rows:
            button=QPushButton();button.setMinimumHeight(63);button.setObjectName('testRow');button.setCursor(Qt.CursorShape.PointingHandCursor)
            layout=QVBoxLayout(button);layout.setContentsMargins(9,7,9,7);layout.setSpacing(3)
            title=QLabel(test_label(key));title.setWordWrap(True);title.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents);layout.addWidget(title)
            status=QLabel();status.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents);layout.addWidget(status);button.status_label=status
            button.clicked.connect(lambda checked=False,k=key:self.select(k));self.tests_layout.addWidget(button);self.rows[key]=button
        state=result.get('state','not_tested')
        labels={'passed':'Пройден','failed':'Ошибка','warning':'Ограничение','needs_action':'Проверить вручную','not_tested':'Не проверен','not_applicable':'Не используется','running':'Выполняется…'}
        level='good' if state=='passed' else 'bad' if state=='failed' else 'attention' if state in ('warning','needs_action','running') else 'neutral'
        button=self.rows[key];button.status_label.setText(labels.get(state,state));button.status_label.setStyleSheet(f'color:{COLORS[level]};font-size:11px;');button.setEnabled(state!='not_applicable')
    def clear(self):
        for row in self.rows.values():self.tests_layout.removeWidget(row);row.deleteLater()
        self.rows.clear();self.live.clear();self.set_health('neutral','Ожидание','Ожидание проверки')
