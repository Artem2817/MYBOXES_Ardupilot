from __future__ import annotations
import argparse,collections,json,math,shutil,sys,time
from pathlib import Path
import numpy as np
from PySide6.QtCore import Qt,QTimer,QPointF
from PySide6.QtGui import QColor,QFont,QPainter,QPen,QPolygonF
from PySide6.QtWidgets import QApplication,QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,QGridLayout,QPushButton,QLabel,QComboBox,QCheckBox,QTabWidget,QTreeWidget,QTreeWidgetItem,QSplitter,QTextEdit,QFileDialog,QMessageBox,QSpinBox,QGroupBox
import pyqtgraph as pg
from serial.tools import list_ports
from .transport import Connection
from .session import Session,STATES
from .orientation import Orientation,rotation,euler
from .instructions import NAMES,CODES,instructions

class BoardView(QWidget):
    def __init__(self):
        super().__init__();self.setMinimumSize(400,280);self.q=np.array([1.,0,0,0]);self.text='Ожидание IMU'
    def paintEvent(self,event):
        p=QPainter(self);p.setRenderHint(QPainter.RenderHint.Antialiasing);p.fillRect(self.rect(),QColor('#111e2c'))
        scale=min(self.width()/4.1,self.height()/3.2)
        # Fixed camera looks down on a spatial board; attitude comes from IMU quaternion.
        camera=np.array([[.75,-.66,0],[.33,.38,-.86],[.57,.65,.51]])
        r=camera@rotation(self.q)
        def project(v):
            x,y,z=r@np.array(v);perspective=4/(4-z);return QPointF(self.width()/2+x*scale*perspective,self.height()/2-y*scale*perspective)
        corners=[[-1,-.65,0],[1,-.65,0],[1,.65,0],[-1,.65,0]]
        top=QPolygonF([project(v) for v in corners]);p.setPen(QPen(QColor('#5df1c4'),2));p.setBrush(QColor('#167b65'));p.drawPolygon(top)
        p.setBrush(QColor('#192333'));p.drawPolygon(QPolygonF([project(v) for v in [[-.25,-.25,.02],[.25,-.25,.02],[.25,.25,.02],[-.25,.25,.02]]]))
        for x in [-.82,.82]:
            for y in [-.48,.48]:p.setBrush(QColor('#c4cbd1'));p.drawEllipse(project([x,y,.02]),5,5)
        p.setPen(QPen(QColor('#fff'),3));p.drawLine(project([.35,0,.03]),project([.9,0,.03]));p.drawLine(project([.9,0,.03]),project([.7,.12,.03]));p.drawLine(project([.9,0,.03]),project([.7,-.12,.03]))
        for v,color,text in [([1.4,0,0],'#ff746b','X · ВПЕРЁД'),([0,1.15,0],'#67ef97','Y'),([0,0,.9],'#72adff','Z')]:
            p.setPen(QPen(QColor(color),2));p.drawLine(project([0,0,0]),project(v));p.drawText(project(v)+QPointF(4,0),text)
        p.setPen(QColor('#d6e4f3'));p.drawText(14,24,'MAYBOX · схема платы');p.drawText(14,self.height()-18,self.text)
        p.end()

class Window(QMainWindow):
    def __init__(self,args):
        super().__init__();self.args=args;self.setWindowTitle('Maybox · диагностика оборудования');self.resize(1380,900)
        self.worker=None;self._workers=[];self.closing=False;self.session=None;self.items={};self.telemetry_items={};self.samples={};self.receipts=collections.defaultdict(lambda:collections.deque(maxlen=200));self.plot_data=collections.defaultdict(lambda:collections.deque(maxlen=3000));self.orientations=collections.defaultdict(Orientation);self._latest_seq={};self.connected=False;self.auto_retry=False;self.last_port=None
        self.output=Path(args.output).resolve();self.output.mkdir(parents=True,exist_ok=True)
        self._build_ui();self.refresh_ports();self.timer=QTimer(self);self.timer.timeout.connect(self.refresh_view);self.timer.start(50)
        if args.demo or args.smoke_demo:QTimer.singleShot(100,self.connect_demo)
        if args.smoke_demo:
            QTimer.singleShot(800,lambda:self.command('run',test='all'))
            QTimer.singleShot(3500,self.smoke_finish)
    def _build_ui(self):
        central=QWidget();self.setCentralWidget(central);layout=QVBoxLayout(central)
        bar=QHBoxLayout();self.ports=QComboBox();self.ports.setEditable(True);self.ports.setMinimumWidth(250);bar.addWidget(self.ports)
        self.refresh_button=QPushButton('Обновить порты');self.refresh_button.clicked.connect(self.refresh_ports);bar.addWidget(self.refresh_button)
        self.connect_button=QPushButton('Подключить');self.connect_button.clicked.connect(self.connect_port);bar.addWidget(self.connect_button)
        b=QPushButton('Отключить');b.clicked.connect(self.disconnect);bar.addWidget(b)
        self.reconnect=QCheckBox('Автоподключение');bar.addWidget(self.reconnect)
        self.profile=QComboBox();self.profile.addItems(['MyboxH743_mini','MyboxH743_mini_v2','MyboxH743_mini_v2_vib']);self.profile.setCurrentIndex(2);bar.addWidget(self.profile)
        b=QPushButton('Демонстрация');b.clicked.connect(self.connect_demo);bar.addWidget(b);layout.addLayout(bar)
        self.banner=QLabel('Устройство не подключено. Демонстрация работает без оборудования.');self.banner.setWordWrap(True);layout.addWidget(self.banner)
        self.board_info=QLabel('Плата: —');self.board_info.setWordWrap(True);layout.addWidget(self.board_info)
        controls=QHBoxLayout()
        self.full=QPushButton('Полная диагностика');self.full.clicked.connect(self.run_full);controls.addWidget(self.full)
        self.single=QPushButton('Запустить выбранную проверку');self.single.clicked.connect(self.run_selected);controls.addWidget(self.single)
        b=QPushButton('Остановить тест');b.clicked.connect(lambda:self.command('stop'));controls.addWidget(b)
        self.rate=QSpinBox();self.rate.setRange(0,100);self.rate.setValue(20);self.rate.setSuffix(' Гц на ПК');controls.addWidget(self.rate)
        b=QPushButton('Частота потока');b.clicked.connect(lambda:self.command('stream',rate=self.rate.value()));controls.addWidget(b)
        b=QPushButton('Сохранить отчёт');b.clicked.connect(self.export);controls.addWidget(b)
        layout.addLayout(controls)
        self.tabs=QTabWidget();layout.addWidget(self.tabs,1)
        test_page=QWidget();tlay=QVBoxLayout(test_page);split=QSplitter(Qt.Orientation.Vertical)
        self.tree=QTreeWidget();self.tree.setHeaderLabels(['Узел / тест','Состояние','Причина','Длительность, мс']);self.tree.setColumnWidth(0,330);self.tree.setColumnWidth(1,220);self.tree.setColumnWidth(2,580);self.tree.currentItemChanged.connect(self.selected_changed);split.addWidget(self.tree)
        details=QWidget();dl=QVBoxLayout(details);self.instructions=QTextEdit();self.instructions.setReadOnly(True);dl.addWidget(self.instructions)
        confirms=QHBoxLayout();self.accept=QPushButton('Подтвердить наблюдаемый результат');self.accept.clicked.connect(lambda:self.confirm_selected(True));confirms.addWidget(self.accept);self.reject=QPushButton('Результат не подтверждён');self.reject.clicked.connect(lambda:self.confirm_selected(False));confirms.addWidget(self.reject);dl.addLayout(confirms);split.addWidget(details);split.setSizes([520,190]);tlay.addWidget(split);self.tabs.addTab(test_page,'Проверки')
        orient_page=QWidget();olay=QVBoxLayout(orient_page);otop=QHBoxLayout();self.imu_select=QComboBox();self.imu_select.addItem('imu0');otop.addWidget(QLabel('IMU:'));otop.addWidget(self.imu_select);b=QPushButton('Установить ноль');b.clicked.connect(self.zero);otop.addWidget(b);otop.addStretch();olay.addLayout(otop)
        self.view=BoardView();olay.addWidget(self.view,1);self.angles=QLabel('Крен — · Тангаж — · Относительный курс —');olay.addWidget(self.angles)
        self.orientation_status=QLabel('Ориентация из аппаратного профиля. Расчёт по IMU не является независимой проверкой датчиков.');self.orientation_status.setWordWrap(True);olay.addWidget(self.orientation_status)
        self.raw=QLabel('Исходные и обработанные данные: —');self.raw.setWordWrap(True);olay.addWidget(self.raw);self.tabs.addTab(orient_page,'Положение платы')
        data_page=QWidget();dlay=QVBoxLayout(data_page);self.sensor_tree=QTreeWidget();self.sensor_tree.setHeaderLabels(['Канал','Значение','Единицы','Возраст, мс','Измерения, Гц','Приём ПК, Гц','Ошибки']);self.sensor_tree.setColumnWidth(0,300);dlay.addWidget(self.sensor_tree);self.tabs.addTab(data_page,'Показания')
        plot_page=QWidget();play=QVBoxLayout(plot_page);pbar=QHBoxLayout();self.channels=QComboBox();self.channels.setMinimumWidth(350);pbar.addWidget(self.channels);self.pause=QCheckBox('Пауза просмотра');pbar.addWidget(self.pause);b=QPushButton('Автомасштаб');b.clicked.connect(lambda:self.plot.enableAutoRange());pbar.addWidget(b);play.addLayout(pbar);self.plot=pg.PlotWidget(background='#111e2c');self.plot.showGrid(x=True,y=True,alpha=.25);self.plot.setLabel('bottom','Время приёма','с');self.curve=self.plot.plot(pen=pg.mkPen('#5df1c4',width=2));play.addWidget(self.plot);self.tabs.addTab(plot_page,'Графики')
        self.log=QTextEdit();self.log.setReadOnly(True);self.log.document().setMaximumBlockCount(1500);self.tabs.addTab(self.log,'Журнал')
        self.summary=QLabel('Итог: неполная проверка');layout.addWidget(self.summary);self.link_stats=QLabel('USB: —');layout.addWidget(self.link_stats)
        self.setStyleSheet('QWidget{font-family:Segoe UI,Arial;font-size:14px;background:#162333;color:#e1edf6} QPushButton{background:#254257;border:1px solid #416279;padding:8px;border-radius:5px} QPushButton:hover{background:#316075} QLineEdit,QComboBox,QSpinBox,QTextEdit,QTreeWidget{background:#101b28;padding:5px} QHeaderView::section{background:#284153;padding:7px} QTabBar::tab{padding:10px} QLabel{padding:3px}')
    def selected_port(self):
        index=self.ports.currentIndex();text=self.ports.currentText().strip()
        return self.ports.itemData(index) if index>=0 and text==self.ports.itemText(index) else text
    def refresh_ports(self):
        previous=self.selected_port();self.ports.clear()
        ports=sorted(list_ports.comports(),key=lambda p:(not (p.vid in (0x0483,0x1209) or 'mybox' in (p.description or '').lower()),p.device))
        for p in ports:self.ports.addItem(f'{p.device} · {p.description}',p.device)
        for i in range(self.ports.count()):
            if self.ports.itemData(i)==previous:self.ports.setCurrentIndex(i);break
    def _new_session(self,demo):
        if self.session:self.session.close()
        self.session=Session(demo);self.session.start_recording(self.output);self.items.clear();self.tree.clear();self.samples.clear();self.sensor_tree.clear();self.telemetry_items.clear();self.plot_data.clear();self.channels.clear();self.receipts.clear();self.orientations.clear();self._latest_seq.clear()
    def _connect(self,port=None,demo=False):
        if self.worker and self.worker.isRunning():self.disconnect();QTimer.singleShot(200,lambda:self._connect(port,demo));return
        self._new_session(demo);self.auto_retry=not demo;self.last_port=port;self.connected=False
        w=Connection(port=port,demo=demo,profile=self.profile.currentText());self.worker=w;self._workers.append(w)
        w.frames.connect(lambda f:self.on_frames(f) if self.worker is w else None);w.status.connect(lambda t:self.on_status(t) if self.worker is w else None);w.fault.connect(lambda t:self.on_fault(t) if self.worker is w else None);w.stats.connect(lambda t:self.on_stats(t) if self.worker is w else None);w.finished.connect(lambda:self._finished(w));w.start()
    def connect_port(self):
        port=self.selected_port()
        if not port:self.on_fault('Выберите или введите COM-порт');return
        self._connect(port)
    def connect_demo(self):self._connect(demo=True)
    def disconnect(self):
        self.auto_retry=False
        if self.worker:self.worker.stop()
    def _finished(self,w):
        if w in self._workers:self._workers.remove(w)
        if self.worker is w:
            self.connected=False
            if self.session:self.session.close()
            if self.auto_retry and self.reconnect.isChecked():QTimer.singleShot(2000,self._retry)
    def _retry(self):
        if self.auto_retry and self.reconnect.isChecked() and (not self.worker or not self.worker.isRunning()):self._connect(self.last_port)
    def on_status(self,text):
        if self.session:self.session.note('connection',state=text)
        self.connected=text in ('Подключено','ДЕМОНСТРАЦИЯ');self.banner.setText('ДЕМОНСТРАЦИЯ — синтетические данные, физическая плата не проверяется' if text=='ДЕМОНСТРАЦИЯ' else text)
        self.banner.setStyleSheet('color:#ffcc67;font-size:18px;font-weight:bold' if text=='ДЕМОНСТРАЦИЯ' else '')
    def on_fault(self,text):
        self.log.append('Ошибка / событие: '+text);self.statusBar().showMessage(text,8000)
        if self.session:self.session.note('transport_error',detail=text)
    def on_stats(self,stats):
        if self.session:self.session.transport=stats
        self.link_stats.setText(f"USB · получено кадров: {stats['received_frames']} · пропуски: {stats['missing_frames']} · повреждения: {stats['parser_errors']} · ожидают ответа: {stats['pending']}")
    def command(self,op,**kw):
        if self.worker and self.worker.isRunning():return self.worker.request(op,**kw)
        self.on_fault('Устройство не подключено')
    def on_frames(self,frames):
        if not self.session or self.closing:return
        now=time.monotonic()
        for f in frames:
            b=f.body
            if f.kind==2 and b.get('op')=='info':
                if self.session.board and self.session.board.get('uid')!=b.get('uid'):self._new_session(bool(b.get('demo')))
                self.board_info.setText(f"{b['profile']} · {b['mcu']} · UID {b['uid']} · {b['firmware']} · сборка {b['build_id']} · протокол {b['protocol']}\nРевизия из сборки; аппаратное определение ревизии отсутствует. Запись сеанса включена.")
                self.imu_select.clear();self.imu_select.addItems([f'imu{i}' for i in range(b.get('imu_count',1))])
            self.session.ingest(f)
            if f.kind==3:
                event=b.get('event')
                if event in ('test','result'):
                    key=b['test'];item=self.items.get(key)
                    if item is None:item=QTreeWidgetItem([key,STATES['not_tested'],'','']);item.setData(0,Qt.ItemDataRole.UserRole,key);self.tree.addTopLevelItem(item);self.items[key]=item
                    definition=self.session.tests.get(key,{})
                    item.setText(0,f"{key} · {NAMES.get(definition.get('method'),definition.get('method',''))}")
                    r=self.session.results.get(key,{});state=r.get('state','not_tested');item.setText(1,STATES.get(state,state));item.setText(2,CODES.get(r.get('code'),r.get('detail',r.get('code',''))));item.setText(3,str(r.get('duration_ms','')))
                    item.setForeground(1,QColor({'passed':'#5df1c4','failed':'#ff827c','warning':'#ffd477','needs_action':'#8ac8ff','running':'#fff'}.get(state,'#adb7c2')))
                elif event=='cycle_complete':self.command('results');self.log.append('Цикл завершён; запрошены сохранённые результаты')
                elif event=='error':self.log.append(json.dumps(b,ensure_ascii=False))
            if f.kind==4:
                sensor=b['sensor'];self.samples[sensor]=(b,now,f.time_ms);self.receipts[sensor].append(now)
                if sensor.startswith('imu'):self.orientations[sensor].update(b)
                for key,value in b.items():
                    if isinstance(value,(int,float)) and not isinstance(value,bool):self._plot_add(f'{sensor}.{key}',now,value)
                    elif key in ('accel_m_s2','gyro_deg_s','raw') and isinstance(value,list):
                        for i,v in enumerate(value):self._plot_add(f'{sensor}.{key}.{i}',now,v)
    def _plot_add(self,key,now,value):
        if value is None or not math.isfinite(value):return
        if key not in self.plot_data:self.channels.addItem(key)
        self.plot_data[key].append((now,value))
    def refresh_view(self):
        if not self.session:return
        self.summary.setText(('ДЕМОНСТРАЦИЯ · ' if self.session.demo else '')+'Итог: '+self.session.conclusion()+f' · записано пакетов телеметрии: {self.session.telemetry_count}')
        sensor=self.imu_select.currentText();o=self.orientations[sensor];
        if sensor in self.samples and time.monotonic()-self.samples[sensor][1]>max(.5,2/max(self.rate.value(),1)):o.state='Нет свежих данных на ПК; ориентация не обновляется'
        q=o.display_q;self.view.q=q;self.view.text=o.state;self.view.update();r,p,y=euler(q)
        self.angles.setText(f'Крен {r:.1f}° · Тангаж {p:.1f}° · Относительный курс {y:.1f}°')
        self.orientation_status.setText(o.state+'\nОриентация из аппаратного профиля. Расчёт по IMU не является независимой проверкой датчиков.')
        if sensor in self.samples:
            b,stamp,frame_ms=self.samples[sensor];self.raw.setText(f"АЦП IMU: {b.get('raw')}\nУскорение, м/с²: {[round(v,4) for v in b.get('accel_m_s2',[])]} · Гироскоп, °/с: {[round(v,4) for v in b.get('gyro_deg_s',[])]}\nТемпература: {b.get('temperature_c')} °C · поправка нуля гироскопа, °/с: {o.bias.round(4).tolist()}")
        now=time.monotonic()
        for sensor,(b,received,frame_ms) in self.samples.items():
            receipt=self.receipts[sensor];hz=(len(receipt)-1)/(receipt[-1]-receipt[0]) if len(receipt)>1 and receipt[-1]>receipt[0] else 0
            age=max(0,(now-received)*1000)+max(0,((frame_ms-b.get('sample_ms',frame_ms))&0xffffffff))
            units={'temperature_c':'°C','pressure_pa':'Па','relative_altitude_m':'м','accel_m_s2':'м/с²','gyro_deg_s':'°/с','raw':'отсчёты','value':b.get('units',''),'adc_voltage_v':'В','scale':'коэффициент'}
            for key,unit in units.items():
                if key not in b:continue
                values=b[key] if isinstance(b[key],list) else [b[key]]
                for i,value in enumerate(values):
                    name=f'{sensor}.{key}'+(f'.{i}' if len(values)>1 else '')
                    item=self.telemetry_items.get(name)
                    if item is None:item=QTreeWidgetItem();self.sensor_tree.addTopLevelItem(item);self.telemetry_items[name]=item
                    cols=[name,f'{value:.5g}' if isinstance(value,(float,int)) else str(value),unit,f'{age:.0f}'+(' · нет свежих' if not b.get('fresh') or now-received>max(.5,2/max(self.rate.value(),1)) else ''),str(b.get('measurement_hz','—')),f'{hz:.1f}' if now-received<2 else '0',str(b.get('errors','—'))]
                    for k,text in enumerate(cols):item.setText(k,text)
        if not self.pause.isChecked():
            channel=self.channels.currentText();data=self.plot_data.get(channel)
            if data:
                a=np.array(data);self.curve.setData(a[:,0]-a[0,0],a[:,1]);self.plot.setLabel('left',channel)
    def zero(self):self.orientations[self.imu_select.currentText()].reset_zero()
    def selected_test(self):
        item=self.tree.currentItem();return item.data(0,Qt.ItemDataRole.UserRole) if item else None
    def selected_changed(self,current,previous):
        key=self.selected_test()
        if not key:return
        r=self.session.results.get(key,{}) if self.session else {}
        detail=CODES.get(r.get('code'),r.get('detail',''))
        self.instructions.setPlainText(instructions(key)+'\n\n'+detail+'\nОжидается: '+r.get('expected','—')+'\nФакт: '+r.get('actual','—'))
    def run_full(self):
        self.command('stop');self.command('run',test='all')
    def run_selected(self):
        key=self.selected_test()
        if not key:self.on_fault('Выберите тест в таблице');return
        confirm=False
        if key.startswith('pwm'):
            answer=QMessageBox.warning(self,'Активный выход',instructions(key)+'\n\nПропеллеры сняты, опасные нагрузки отключены?',QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No,QMessageBox.StandardButton.No)
            if answer!=QMessageBox.StandardButton.Yes:return
            confirm=True
        self.command('run',test=key,confirm=confirm,duration_ms=1000)
    def confirm_selected(self,accepted):
        key=self.selected_test()
        if not key:return
        r=self.session.results.get(key,{})
        if r.get('state')!='needs_action':self.on_fault('Для этого теста нет ожидающего подтверждения');return
        method=self.session.tests.get(key,{}).get('method')
        if method not in ('visual','audible','50hz_1000us_scope'):self.on_fault('Этому тесту нужны измерения; ручное подтверждение не заменяет их');return
        self.session.confirm(key,accepted);self.command('confirm',test=key,confirm=accepted)
    def export(self):
        if not self.session:return
        directory=QFileDialog.getExistingDirectory(self,'Папка для отчёта',str(self.output))
        if directory:
            report=self.session.export(directory)
            if self.session._csv:self.session._csv.flush()
            source=self.session.directory/'telemetry.csv'
            if source.resolve()!= (Path(directory)/'telemetry.csv').resolve():shutil.copy2(source,Path(directory)/'telemetry.csv')
            self.statusBar().showMessage('Сохранено: '+str(report),10000)
    def smoke_finish(self):
        if not self.session or not self.session.board or not self.session.latest:
            print('DEMO_SMOKE_FAILED',flush=True);QApplication.instance().exit(2);return
        self.tabs.setCurrentIndex(1);self.refresh_view();self.grab().save(str(self.output/'demo-window.png'));self.session.export(self.output/'demo-report');self.session._csv.flush();shutil.copy2(self.session.directory/'telemetry.csv',self.output/'demo-report/telemetry.csv');print('DEMO_SMOKE_OK',flush=True);self.close()
    def closeEvent(self,event):
        self.closing=True
        self.auto_retry=False
        for w in self._workers:w.stop()
        for w in list(self._workers):
            if not w.wait(1500):event.ignore();QTimer.singleShot(1000,self.close);return
        if self.session:self.session.close()
        event.accept()

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--demo',action='store_true');parser.add_argument('--smoke-demo',action='store_true');parser.add_argument('--output',default='MayboxReports');args=parser.parse_args()
    app=QApplication(sys.argv[:1]);pg.setConfigOptions(antialias=False);window=Window(args);window.show();return app.exec()
if __name__=='__main__':raise SystemExit(main())
