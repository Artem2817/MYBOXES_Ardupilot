"""Maybox bench diagnostics. GPL-3.0-or-later."""
__version__='0.1.0'
