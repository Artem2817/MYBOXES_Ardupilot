@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe py -3 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements-build.txt
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe -m PyInstaller --noconfirm --clean --onedir --windowed --name MayboxDiag --distpath ..\dist\windows --workpath ..\.windows-build\work --specpath ..\.windows-build --add-data "maybox_diag\profiles;maybox_diag\profiles" --add-data "maybox_diag\test_catalog.json;maybox_diag" run.py
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe ..\tools\package_windows.py
