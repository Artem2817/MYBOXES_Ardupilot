#!/usr/bin/env python3
"""Validate checksum, non-overlap and application-only address range of every HEX."""
from pathlib import Path
import argparse,hashlib,json,struct,zlib

def inspect(path):
    memory={};upper=0;eof=False
    for no,line in enumerate(path.read_text().splitlines(),1):
        if eof:raise ValueError(f'{path}:{no}: records after EOF')
        if not line.startswith(':'):raise ValueError(f'{path}:{no}: no record marker')
        raw=bytes.fromhex(line[1:]);count=raw[0];offset=int.from_bytes(raw[1:3],'big');kind=raw[3]
        if len(raw)!=count+5 or sum(raw)&255:raise ValueError(f'{path}:{no}: bad length/checksum')
        data=raw[4:-1]
        if kind==0:
            for i,b in enumerate(data):
                address=upper+offset+i
                if not 0x08020000<=address<0x081c0000:raise ValueError(f'Write outside application: 0x{address:08x}')
                if address in memory:raise ValueError('Overlapping HEX records')
                memory[address]=b
        elif kind==4:
            if count!=2:raise ValueError('Invalid extended address')
            upper=int.from_bytes(data,'big')<<16
        elif kind==1:eof=True
        elif kind==5:
            if count!=4:raise ValueError('Invalid entrypoint')
        else:raise ValueError('Unexpected record kind')
    if not eof or not memory:raise ValueError('Empty or unterminated HEX')
    start=min(memory);end=max(memory)+1
    if start!=0x08020000:raise ValueError('Incorrect application start')
    readword=lambda a:int.from_bytes(bytes(memory.get(a+i,0) for i in range(4)),'little')
    stack=readword(start);reset=readword(start+4)
    if not any(lo<stack<=hi for lo,hi in [(0x20000000,0x20020000),(0x24000000,0x24080000),(0x30000000,0x30048000),(0x38000000,0x38010000)]):raise ValueError('Stack pointer outside H743 RAM')
    if not reset&1 or not start<=(reset&~1)<end:raise ValueError('Invalid reset vector')
    image=bytes(memory.get(a,255) for a in range(start,end))
    signature=bytes.fromhex('40a2e4f164689106');offset=image.find(signature)
    if offset<0 or image.find(signature,offset+1)>=0:raise ValueError('Missing or ambiguous ArduPilot app descriptor')
    crc1,crc2,image_size,git_hash=struct.unpack_from('<IIII',image,offset+8)
    crc0=lambda b:(zlib.crc32(b,0xffffffff)^0xffffffff)&0xffffffff
    if image_size!=len(image):raise ValueError('Descriptor image length mismatch')
    if crc1!=crc0(image[:offset+8]) or crc2!=crc0(image[offset+24:]):raise ValueError('Bootloader image CRC mismatch')
    board_id=struct.unpack_from('<H',image,offset+26)[0]
    expected=1480 if 'v2_vib' in path.name else 1479 if 'v2' in path.name else 1478
    if board_id!=expected:raise ValueError('Bootloader board ID mismatch')
    return dict(name=path.name,start=hex(start),end_exclusive=hex(end),programmed_bytes=len(memory),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),reset=hex(reset),bootloader_descriptor_crc_valid=True,board_id=board_id)
def main():
    p=argparse.ArgumentParser();p.add_argument('directory',type=Path);a=p.parse_args();paths=sorted(a.directory.glob('MayboxDiag-*.hex'))
    if len(paths)!=3:raise SystemExit('Expected exactly three diagnostic HEX files')
    result=[inspect(f) for f in paths];out=a.directory/'hex-validation.json';out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
