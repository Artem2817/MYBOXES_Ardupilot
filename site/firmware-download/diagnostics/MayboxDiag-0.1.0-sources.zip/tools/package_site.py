#!/usr/bin/env python3
from pathlib import Path
import json,hashlib,shutil,zipfile
KIT=Path(__file__).resolve().parents[1]
def main():
 site=KIT/'site-source';dest=site/'diagnostics';dest.mkdir(exist_ok=True)
 rows=[]
 for m in sorted(json.loads((KIT/'dist/firmware/manifest.json').read_text()),key=lambda m:m['profile']):
  name=f"MayboxDiag-0.1.0-{m['profile']}.hex";f=KIT/'dist/firmware'/name;shutil.copy2(f,dest/name)
  rows.append({**m,'file':'diagnostics/'+name,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'size':f.stat().st_size})
 if len(rows)!=3:raise SystemExit('Package all three profiles before publication')
 (dest/'manifest.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
 for name in ['SHA256SUMS.txt','hex-validation.json']:shutil.copy2(KIT/'dist/firmware'/name,dest/name)
 for name in ['HARDWARE.ru.md','COVERAGE.ru.md','PROTOCOL.ru.md','ACCEPTANCE.ru.md','RETURN.ru.md']:
  if (KIT/'docs'/name).exists():shutil.copy2(KIT/'docs'/name,dest/name)
 shutil.copy2(KIT/'README.ru.md',dest/'README.ru.md')
 with zipfile.ZipFile(dest/'MayboxDiag-0.1.0-sources.zip','w',zipfile.ZIP_DEFLATED) as z:
  for folder in ['firmware','pc','profiles','config','tools','tests','docs','hardware']:
   for p in (KIT/folder).rglob('*'):
    if p.is_file() and not any(part in ('__pycache__','.venv') for part in p.parts) and p.suffix not in ('.pyc',):z.write(p,p.relative_to(KIT))
  for f in (KIT/'site-source').rglob('*'):
   rel=f.relative_to(KIT/'site-source')
   if f.is_file() and 'diagnostics' not in rel.parts and f.name!='firmware-index.json' and f.suffix in ('.html','.css','.js','.json','.png'):z.write(f,f.relative_to(KIT))
  for name in ['README.ru.md','LICENSE']:z.write(KIT/name,name)
  for f in (KIT/'examples/demo-report').glob('*'):
   if f.is_file():z.write(f,f.relative_to(KIT))
  for name in ['demo-window.png','test-results.txt','site-baseline-tests.txt']:
   z.write(KIT/'examples'/name,'examples/'+name)
 manifest=dict(schema=1,version='0.1.0',channel='bench',physical_validation=False,application_address='0x08020000',bootloader_included=False,profiles=rows)
 (site/'diagnostic-index.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
 # Separate window/tab; original firmware routing is not involved.
 cards=[]
 for r in rows:
  cards.append(f'<article><h2>{r["profile"]}</h2><p>STM32H743 · MayboxDiag 0.1.0 · только стенд · физическое испытание не проведено</p><a href="{r["file"]}" download>Скачать диагностический HEX</a><code>SHA-256: {r["sha256"]}</code><p>Сборка {r["build_id"]} · начало приложения 0x08020000 · загрузчик не включён.</p></article>')
 page='''<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Maybox · диагностические прошивки</title><link rel="stylesheet" href="styles.css?v=3"></head><body><header class="shell hero"><nav class="nav"><a class="repo-link" href="./">Каталог ArduPilot / INAV</a><a class="repo-link" href="./#hardware-reference">Распиновка и DShot</a></nav><h1>Диагностика<br><em>оборудования Maybox.</em></h1><p class="hero-copy">Отдельное приложение для стенда и программа для Windows: датчики, USB, проверки узлов, графики и отчёты.</p></header><main class="shell"><aside class="diagnostic-warning">Три HEX собраны программно. Испытание на физической плате в этом сеансе не проводилось. Эти образы предназначены для стенда. Снимите пропеллеры и отключите опасные нагрузки перед активными проверками выходов. Диагностические HEX начинаются с 0x08020000 и не содержат загрузчик; не выполняйте полное стирание Flash. При переходе с INAV нужен совместимый загрузчик ArduPilot или запуск приложения через SWD. Сначала прочитайте инструкцию.</aside><div class="diagnostic-list">'''+''.join(cards)+'''</div><section class="format-guide"><h2>Программа и инструкции</h2><div class="diagnostic-list"><article><a href="diagnostics/MayboxDiag-0.1.0-sources.zip" download>Исходники прошивки и программы ПК</a><a href="diagnostics/README.ru.md">Инструкция</a><a href="diagnostics/COVERAGE.ru.md">Покрытие и ограничения</a><a href="diagnostics/PROTOCOL.ru.md">Протокол USB</a><a href="diagnostics/RETURN.ru.md">Возврат штатной прошивки</a><a href="diagnostics/manifest.json">Манифест сборок</a><p>Русский интерфейс, PySide6, pyserial и pyqtgraph. Есть явно обозначенный демонстрационный режим. Результаты демонстрации не являются проверкой настоящей платы.</p></article></div></section></main><footer class="shell footer">MYBOXES · MayboxDiag · стендовая диагностика</footer></body></html>'''
 (site/'diagnostics.html').write_text(page,encoding='utf-8');print('Packaged three diagnostic HEX files and source bundle')
if __name__=='__main__':main()
