#!/usr/bin/env python3
"""Package an already-built Windows application together with notices and checksums."""
from pathlib import Path
import argparse,hashlib,json,shutil,sysconfig,zipfile
KIT=Path(__file__).resolve().parents[1]
def main():
 p=argparse.ArgumentParser();p.add_argument('--dependencies',type=Path,default=Path(sysconfig.get_paths()['purelib']));p.add_argument('--native-demo-tested',action='store_true');a=p.parse_args()
 app=KIT/'dist/windows/MayboxDiag'
 if not (app/'MayboxDiag.exe').is_file():raise SystemExit('Build the Windows application first')
 notices=app/'ThirdPartyLicenses';notices.mkdir(exist_ok=True)
 for package in a.dependencies.glob('*.dist-info'):
  for source in package.rglob('*'):
   if source.is_file() and any(word in source.name.lower() for word in ('license','copying','metadata')):
    target=notices/package.name/source.relative_to(package);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
 shutil.copy2(KIT/'LICENSE',app/'LICENSE.txt');shutil.copy2(KIT/'README.ru.md',app/'README.ru.md')
 target=KIT/'dist/MayboxDiag-0.1.0-windows-x64.zip'
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
  for source in app.rglob('*'):
   if source.is_file():archive.write(source,source.relative_to(KIT/'dist/windows'))
 sha=hashlib.sha256(target.read_bytes()).hexdigest()
 (KIT/'dist/windows-package.json').write_text(json.dumps(dict(file=target.name,sha256=sha,native_windows_demo_tested=a.native_demo_tested,physical_board_tested=False),indent=2)+'\n')
 print(target.name,sha)
if __name__=='__main__':main()
